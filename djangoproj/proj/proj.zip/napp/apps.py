from django.apps import AppConfig


class NappConfig(AppConfig):
    name = 'napp'
